/*
	Quick test routine for MyGL
	Version 1.0.4

	Author: Rafael Sabe
	Email: rafaelmsabe@gmail.com
*/

#include "globldef.h"
#include "cstrdef.h"
#include "strdef.hpp"

#include <math.h>
#include <GL/gl.h>

#include "MyGL.hpp"

#define CUSTOM_GENERIC_WNDCLASS_NAME TEXT("__CUSTOMGENERICWNDCLASS__")

#define RUNTIME_STATUS_INIT 0
#define RUNTIME_STATUS_IDLE 1
#define RUNTIME_STATUS_DRAW 2

#define CUSTOM_COLORREF_BLACK 0x00000000
#define CUSTOM_COLORREF_WHITE 0x00ffffff
#define CUSTOM_COLORREF_LTGRAY 0x00c0c0c0
#define CUSTOM_COLORREF_RED 0x000000ff
#define CUSTOM_COLORREF_GREEN 0x0000ff00
#define CUSTOM_COLORREF_BLUE 0x00ff0000

#define BRUSHINDEX_TRANSPARENT 0U
#define BRUSHINDEX_CUSTOM_SOLID_BLACK 1U
#define BRUSHINDEX_CUSTOM_SOLID_WHITE 2U
#define BRUSHINDEX_CUSTOM_SOLID_LTGRAY 3U

#define PP_BRUSH_LENGTH 4U
#define PP_BRUSH_SIZE (PP_BRUSH_LENGTH*sizeof(HBRUSH))

#define CUSTOMFONT_TITLE_CHARSET DEFAULT_CHARSET
#define CUSTOMFONT_TITLE_WIDTH 20U
#define CUSTOMFONT_TITLE_HEIGHT 35U
#define CUSTOMFONT_TITLE_WEIGHT FW_NORMAL

#define CUSTOMFONT_TEXT_CHARSET DEFAULT_CHARSET
#define CUSTOMFONT_TEXT_WIDTH 8U
#define CUSTOMFONT_TEXT_HEIGHT 16U
#define CUSTOMFONT_TEXT_WEIGHT FW_NORMAL

#define FONTINDEX_CUSTOM_TITLE 0U
#define FONTINDEX_CUSTOM_TEXT 1U

#define PP_FONT_LENGTH 2U
#define PP_FONT_SIZE (PP_FONT_LENGTH*sizeof(HFONT))

#define CHILDWNDINDEX_TEXT1 0U
#define CHILDWNDINDEX_BUTTON1 1U

#define PP_CHILDWND_LENGTH 2U
#define PP_CHILDWND_SIZE (PP_CHILDWND_LENGTH*sizeof(HWND))

#define MAINWND_CAPTION TEXT("MyGL Lib Test")

#define MAINWND_BKCOLORREF CUSTOM_COLORREF_LTGRAY
#define MAINWND_BRUSHINDEX BRUSHINDEX_CUSTOM_SOLID_LTGRAY

#define TEXTWND_TEXTCOLORREF CUSTOM_COLORREF_BLACK
#define TEXTWND_BKCOLORREF MAINWND_BKCOLORREF
#define TEXTWND_BRUSHINDEX BRUSHINDEX_TRANSPARENT

#define DRAWPROC_X_DOMAIN 6.28F
#define DRAWPROC_X_STEP 0.01F
#define DRAWPROC_DELAYTIME_MS 1U

static __declspec(align(PTR_SIZE_BYTES)) HBRUSH pp_brush[PP_BRUSH_LENGTH] = {NULL};
static __declspec(align(PTR_SIZE_BYTES)) HFONT pp_font[PP_FONT_LENGTH] = {NULL};
static __declspec(align(PTR_SIZE_BYTES)) HWND pp_childwnd[PP_CHILDWND_LENGTH] = {NULL};

static __declspec(align(PTR_SIZE_BYTES)) HWND p_mainwnd = NULL;
static __declspec(align(PTR_SIZE_BYTES)) MyGL *p_mygl = NULL;

static __declspec(align(4)) INT runtime_status = -1;
static __declspec(align(4)) INT prev_status = -1;
static __declspec(align(4)) INT aux_status = -1;

static __declspec(align(2)) WORD custom_generic_wndclass_id = 0u;

static BOOL WINAPI app_init(VOID);
static VOID WINAPI app_deinit(VOID);

static __declspec(noreturn) VOID WINAPI app_exit(UINT exit_code, const TCHAR *exit_msg);

static BOOL WINAPI gdiobj_init(VOID);
static VOID WINAPI gdiobj_deinit(VOID);

static BOOL WINAPI register_wndclass(VOID);
static BOOL WINAPI create_mainwnd(VOID);
static BOOL WINAPI create_childwnd(VOID);

static INT WINAPI app_get_ref_status(VOID);

static VOID WINAPI runtime_loop(VOID);

static VOID WINAPI paintscreen_base(VOID);
static VOID WINAPI drawproc_loop(VOID);

static BOOL WINAPI glwnd_paintbk(MyGL *p_myglobj, COLORREF color);

static VOID WINAPI childwnd_setup(BOOL redraw_mainwnd);
static BOOL WINAPI window_get_dimensions(HWND p_wnd, INT *p_xpos, INT *p_ypos, INT *p_width, INT *p_height, INT *p_centerx, INT *p_centery);
static BOOL WINAPI mainwnd_redraw(VOID);

static BOOL WINAPI catch_messages(VOID);

static LRESULT CALLBACK mainwnd_wndproc(HWND p_wnd, UINT msg, WPARAM wparam, LPARAM lparam);
static LRESULT CALLBACK mainwnd_event_wmdestroy(HWND p_wnd, WPARAM wparam, LPARAM lparam);
static LRESULT CALLBACK mainwnd_event_wmsize(HWND p_wnd, WPARAM wparam, LPARAM lparam);
static LRESULT CALLBACK mainwnd_event_wmpaint(HWND p_wnd, WPARAM wparam, LPARAM lparam);

static LRESULT CALLBACK glwnd_wndproc(HWND p_wnd, UINT msg, WPARAM wparam, LPARAM lparam);

static LRESULT CALLBACK window_event_wmctlcolorstatic(HWND p_wnd, WPARAM wparam, LPARAM lparam);

static inline INT debug_msgbox(const TCHAR *text, UINT type)
{
	return MessageBox(NULL, text, TEXT("DEBUG"), type);
}

static inline INT debug_msgbox(__string str, UINT type)
{
	return MessageBox(NULL, str.c_str(), TEXT("DEBUG"), type);
}

INT WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, INT nShowCmd)
{
	p_instance = hInstance;
	if(!app_init()) return -1;

	runtime_loop();
	app_deinit();
	return 0;
}

static BOOL WINAPI app_init(VOID)
{
	if(p_instance == NULL)
	{
		__SPRINTF(textbuf, TEXTBUF_SIZE_CHARS, TEXT("Error: invalid instance handle."));
		goto _l_app_init_error;
	}

	p_processheap = GetProcessHeap();
	if(p_processheap == NULL)
	{
		__SPRINTF(textbuf, TEXTBUF_SIZE_CHARS, TEXT("Error: failed to retrieve process heap."));
		goto _l_app_init_error;
	}

	if(!gdiobj_init())
	{
		__SPRINTF(textbuf, TEXTBUF_SIZE_CHARS, TEXT("Error: WINGDI object init failed."));
		goto _l_app_init_error;
	}

	if(!register_wndclass())
	{
		__SPRINTF(textbuf, TEXTBUF_SIZE_CHARS, TEXT("Error: WNDCLASS register failed."));
		goto _l_app_init_error;
	}

	if(!create_mainwnd())
	{
		__SPRINTF(textbuf, TEXTBUF_SIZE_CHARS, TEXT("Error: create MAINWND failed."));
		goto _l_app_init_error;
	}

	if(!create_childwnd())
	{
		__SPRINTF(textbuf, TEXTBUF_SIZE_CHARS, TEXT("Error: create CHILDWND failed."));
		goto _l_app_init_error;
	}

	runtime_status = RUNTIME_STATUS_INIT;
	return TRUE;

_l_app_init_error:

	MessageBox(NULL, textbuf, TEXT("INIT ERROR"), (MB_ICONSTOP | MB_OK));
	app_deinit();
	return FALSE;
}

static VOID WINAPI app_deinit(VOID)
{
	if(p_mainwnd != NULL) DestroyWindow(p_mainwnd);

	if(custom_generic_wndclass_id)
	{
		UnregisterClass(CUSTOM_GENERIC_WNDCLASS_NAME, p_instance);
		custom_generic_wndclass_id = 0u;
	}

	gdiobj_deinit();
	return;
}

static __declspec(noreturn) VOID WINAPI app_exit(UINT exit_code, const TCHAR *exit_msg)
{
	app_deinit();

	if(exit_msg != NULL) MessageBox(NULL, exit_msg, TEXT("PROCESS EXIT CALLED"), (MB_ICONSTOP | MB_OK));

	ExitProcess(exit_code);

	while(TRUE) Sleep(16u);
}

static BOOL WINAPI gdiobj_init(VOID)
{
	ULONG_PTR n_obj;
	LOGFONT logfont;

	pp_brush[BRUSHINDEX_TRANSPARENT] = (HBRUSH) GetStockObject(HOLLOW_BRUSH);
	pp_brush[BRUSHINDEX_CUSTOM_SOLID_BLACK] = CreateSolidBrush(CUSTOM_COLORREF_BLACK);
	pp_brush[BRUSHINDEX_CUSTOM_SOLID_WHITE] = CreateSolidBrush(CUSTOM_COLORREF_WHITE);
	pp_brush[BRUSHINDEX_CUSTOM_SOLID_LTGRAY] = CreateSolidBrush(CUSTOM_COLORREF_LTGRAY);

	for(n_obj = 0u; n_obj < PP_BRUSH_LENGTH; n_obj++) if(pp_brush[n_obj] == NULL) return FALSE;

	ZeroMemory(&logfont, sizeof(LOGFONT));

	logfont.lfCharSet = CUSTOMFONT_TITLE_CHARSET;
	logfont.lfWidth = CUSTOMFONT_TITLE_WIDTH;
	logfont.lfHeight = CUSTOMFONT_TITLE_HEIGHT;
	logfont.lfWeight = CUSTOMFONT_TITLE_WEIGHT;

	pp_font[FONTINDEX_CUSTOM_TITLE] = CreateFontIndirect(&logfont);

	logfont.lfCharSet = CUSTOMFONT_TEXT_CHARSET;
	logfont.lfWidth = CUSTOMFONT_TEXT_WIDTH;
	logfont.lfHeight = CUSTOMFONT_TEXT_HEIGHT;
	logfont.lfWeight = CUSTOMFONT_TEXT_WEIGHT;

	pp_font[FONTINDEX_CUSTOM_TEXT] = CreateFontIndirect(&logfont);

	for(n_obj = 0u; n_obj < PP_FONT_LENGTH; n_obj++) if(pp_font[n_obj] == NULL) return FALSE;

	return TRUE;
}

static VOID WINAPI gdiobj_deinit(VOID)
{
	ULONG_PTR n_obj;

	for(n_obj = 0u; n_obj < PP_BRUSH_LENGTH; n_obj++)
	{
		if(pp_brush[n_obj] != NULL)
		{
			DeleteObject(pp_brush[n_obj]);
			pp_brush[n_obj] = NULL;
		}
	}

	for(n_obj = 0u; n_obj < PP_FONT_LENGTH; n_obj++)
	{
		if(pp_font[n_obj] != NULL)
		{
			DeleteObject(pp_font[n_obj]);
			pp_font[n_obj] = NULL;
		}
	}

	return;
}

static BOOL WINAPI register_wndclass(VOID)
{
	WNDCLASS wndclass;

	ZeroMemory(&wndclass, sizeof(WNDCLASS));

	wndclass.style = CS_OWNDC;
	wndclass.lpfnWndProc = &DefWindowProc;
	wndclass.hInstance = p_instance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = pp_brush[BRUSHINDEX_TRANSPARENT];
	wndclass.lpszClassName = CUSTOM_GENERIC_WNDCLASS_NAME;

	custom_generic_wndclass_id = RegisterClass(&wndclass);

	return (BOOL) custom_generic_wndclass_id;
}

static BOOL WINAPI create_mainwnd(VOID)
{
	DWORD style = (WS_CAPTION | WS_VISIBLE | WS_SYSMENU | WS_OVERLAPPED | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SIZEBOX);

	p_mainwnd = CreateWindow(CUSTOM_GENERIC_WNDCLASS_NAME, MAINWND_CAPTION, style, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, p_instance, NULL);
	if(p_mainwnd == NULL) return FALSE;

	if(SetWindowLongPtr(p_mainwnd, GWLP_WNDPROC, (LONG_PTR) &mainwnd_wndproc)) return TRUE;

	return FALSE;
}

static BOOL WINAPI create_childwnd(VOID)
{
	ULONG_PTR n_wnd;
	HDC p_wnddc;
	DWORD style;
	INT pixel_format;
	PIXELFORMATDESCRIPTOR pfd;

	style = (WS_CHILD | SS_CENTER);

	pp_childwnd[CHILDWNDINDEX_TEXT1] = CreateWindow(TEXT("STATIC"), TEXT("Test OPENGL"), style, 0, 0, 0, 0, p_mainwnd, NULL, p_instance, NULL);

	style = (WS_CHILD | WS_TABSTOP | BS_PUSHBUTTON | BS_TEXT | BS_CENTER | BS_VCENTER);

	pp_childwnd[CHILDWNDINDEX_BUTTON1] = CreateWindow(TEXT("BUTTON"), TEXT("Does Nothing"), style, 0, 0, 0, 0, p_mainwnd, NULL, p_instance, NULL);

	for(n_wnd = 0u; n_wnd < PP_CHILDWND_LENGTH; n_wnd++) if(pp_childwnd[n_wnd] == NULL) return FALSE;

	style = WS_CHILD;

	p_mygl = new MyGL();
	if(p_mygl == NULL) return FALSE;

	p_mygl->p_wnd = CreateWindow(CUSTOM_GENERIC_WNDCLASS_NAME, NULL, style, 0, 0, 0, 0, p_mainwnd, NULL, p_instance, NULL);
	if(p_mygl->p_wnd == NULL) return FALSE;

	if(!SetWindowLongPtr(p_mygl->p_wnd, GWLP_WNDPROC, (LONG_PTR) &glwnd_wndproc)) return FALSE;

	p_wnddc = GetDC(p_mygl->p_wnd);
	if(p_wnddc == NULL) return FALSE;

	ZeroMemory(&pfd, sizeof(PIXELFORMATDESCRIPTOR));

	pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion = 1;
	pfd.dwFlags = (PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_GENERIC_FORMAT | PFD_DEPTH_DONTCARE | PFD_DOUBLEBUFFER_DONTCARE | PFD_STEREO_DONTCARE);
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 24u;

	pixel_format = ChoosePixelFormat(p_wnddc, &pfd);
	if(!pixel_format) return FALSE;

	if(!SetPixelFormat(p_wnddc, pixel_format, &pfd)) return FALSE;

	ReleaseDC(p_mygl->p_wnd, p_wnddc);
	p_wnddc = NULL;

	if(!p_mygl->initialize()) return FALSE;

	SendMessage(pp_childwnd[CHILDWNDINDEX_TEXT1], WM_SETFONT, (WPARAM) pp_font[FONTINDEX_CUSTOM_TITLE], (LPARAM) TRUE);

	return TRUE;
}

static INT WINAPI app_get_ref_status(VOID)
{
	switch(runtime_status)
	{
		case RUNTIME_STATUS_IDLE:
		case RUNTIME_STATUS_DRAW:

			return prev_status;
	}

	return runtime_status;
}

static VOID WINAPI runtime_loop(VOID)
{
	INT runtime_status_newvalue;

	while(catch_messages())
	{
		switch(runtime_status)
		{
			case RUNTIME_STATUS_IDLE:
				Sleep(16u);
				break;

			case RUNTIME_STATUS_INIT:
				paintscreen_base();
				childwnd_setup(TRUE);

				p_mygl->makeCurrentGL();

				glwnd_paintbk(p_mygl, CUSTOM_COLORREF_BLACK);

				p_mygl->addPointSizeEntry(2.0f, FALSE);
				glPointSize(2.0f);

				runtime_status_newvalue = RUNTIME_STATUS_DRAW;
				goto _l_runtime_loop_updatestatus;

			case RUNTIME_STATUS_DRAW:
				drawproc_loop();
				glFlush();
				break;
		}

_l_runtime_loop_loopback:

		continue;

_l_runtime_loop_updatestatus:

		prev_status = runtime_status;
		runtime_status = runtime_status_newvalue;
	}

	return;
}

static VOID WINAPI paintscreen_base(VOID)
{
	ShowWindow(pp_childwnd[CHILDWNDINDEX_TEXT1], SW_SHOW);
	ShowWindow(pp_childwnd[CHILDWNDINDEX_BUTTON1], SW_SHOW);
	ShowWindow(p_mygl->p_wnd, SW_SHOW);

	return;
}

static VOID WINAPI drawproc_loop(VOID)
{
	static FLOAT x = 0.0f;
	static FLOAT y = 0.0f;
	static FLOAT yi = 0.0f;
	static FLOAT d = 0.0f;
	static FLOAT i = 0.0f;

	FLOAT fcx;
	FLOAT fcy;
	COLORREF color;

	if(x >= DRAWPROC_X_DOMAIN)
	{
		runtime_status = RUNTIME_STATUS_IDLE;
		return;
	}

	y = sinf(x) + sinf(3.0f*x)/3.0f + sinf(5.0f*x)/5.0f + sinf(7.0f*x)/7.0f;
	d = (y - yi)/DRAWPROC_X_STEP;
	i += y*DRAWPROC_X_STEP;
	yi = y;

	glBegin(GL_POINTS);

	fcx = 2.0f*x/DRAWPROC_X_DOMAIN - 1.0f;

	fcy = 0.25f*y;
	color = CUSTOM_COLORREF_RED;

	p_mygl->addColorEntry(color, FALSE);
	p_mygl->addPointObjectEntry(fcx, fcy, FALSE);
	mygl_setcolor(color);
	glVertex2f(fcx, fcy);

	fcy = 0.25f*d;
	color = CUSTOM_COLORREF_GREEN;

	p_mygl->addColorEntry(color, FALSE);
	p_mygl->addPointObjectEntry(fcx, fcy, FALSE);
	mygl_setcolor(color);
	glVertex2f(fcx, fcy);

	fcy = 0.25f*i;
	color = CUSTOM_COLORREF_BLUE;

	p_mygl->addColorEntry(color, FALSE);
	p_mygl->addPointObjectEntry(fcx, fcy, FALSE);
	mygl_setcolor(color);
	glVertex2f(fcx, fcy);

	glEnd();

	Sleep(DRAWPROC_DELAYTIME_MS);
	x += DRAWPROC_X_STEP;

	return;
}

static BOOL WINAPI glwnd_paintbk(MyGL *p_myglobj, COLORREF color)
{
	if(p_myglobj == NULL) return FALSE;

	p_myglobj->addColorEntry(color, FALSE);
	p_myglobj->addQuadObjectEntry(-1.0f, 1.0f, 1.0f, 1.0f, 1.0f, -1.0f, -1.0f, -1.0f, FALSE);

	mygl_setcolor(color);

	glBegin(GL_QUADS);
	glVertex2f(-1.0f, 1.0f);
	glVertex2f(1.0f, 1.0f);
	glVertex2f(1.0f, -1.0f);
	glVertex2f(-1.0f, -1.0f);
	glEnd();

	return TRUE;
}

static VOID WINAPI childwnd_setup(BOOL redraw_mainwnd)
{
	INT mainwnd_width;
	INT mainwnd_height;
	INT mainwnd_centerx;

	INT text1_dim[4];
	INT button1_dim[4];
	INT glwnd_dim[4];

	window_get_dimensions(p_mainwnd, NULL, NULL, &mainwnd_width, &mainwnd_height, &mainwnd_centerx, NULL);

	text1_dim[0] = 20;
	text1_dim[1] = 20;
	text1_dim[2] = mainwnd_width - 2*(text1_dim[0]);
	text1_dim[3] = CUSTOMFONT_TITLE_HEIGHT;

	button1_dim[2] = 120;
	button1_dim[3] = 20;
	button1_dim[0] = mainwnd_centerx - button1_dim[2]/2;
	button1_dim[1] = mainwnd_height - button1_dim[3] - 60;

	glwnd_dim[0] = text1_dim[0];
	glwnd_dim[1] = text1_dim[1] + text1_dim[3] + 10;
	glwnd_dim[2] = mainwnd_width - 2*(glwnd_dim[0]);
	glwnd_dim[3] = button1_dim[1] - glwnd_dim[1] - 10;

	SetWindowPos(pp_childwnd[CHILDWNDINDEX_TEXT1], NULL, text1_dim[0], text1_dim[1], text1_dim[2], text1_dim[3], 0u);
	SetWindowPos(pp_childwnd[CHILDWNDINDEX_BUTTON1], NULL, button1_dim[0], button1_dim[1], button1_dim[2], button1_dim[3], 0u);
	SetWindowPos(p_mygl->p_wnd, NULL, glwnd_dim[0], glwnd_dim[1], glwnd_dim[2], glwnd_dim[3], 0u);

	if(redraw_mainwnd) mainwnd_redraw();
	return;
}

static BOOL WINAPI window_get_dimensions(HWND p_wnd, INT *p_xpos, INT *p_ypos, INT *p_width, INT *p_height, INT *p_centerx, INT *p_centery)
{
	RECT rect;

	if(p_wnd == NULL) return FALSE;
	if(!GetWindowRect(p_wnd, &rect)) return FALSE;

	if(p_xpos != NULL) *p_xpos = rect.left;
	if(p_ypos != NULL) *p_ypos = rect.top;
	if(p_width != NULL) *p_width = rect.right - rect.left;
	if(p_height != NULL) *p_height = rect.bottom - rect.top;
	if(p_centerx != NULL) *p_centerx = (rect.right - rect.left)/2;
	if(p_centery != NULL) *p_centery = (rect.bottom - rect.top)/2;

	return TRUE;
}

static BOOL WINAPI mainwnd_redraw(VOID)
{
	if(p_mainwnd == NULL) return FALSE;

	RedrawWindow(p_mainwnd, NULL, NULL, (RDW_ERASE | RDW_FRAME | RDW_INTERNALPAINT | RDW_INVALIDATE | RDW_UPDATENOW | RDW_ALLCHILDREN));

	p_mygl->updateWndCtx();
	p_mygl->paintBufferGL();
	glFlush();

	return TRUE;
}

static BOOL WINAPI catch_messages(VOID)
{
	MSG msg;
	while(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
	{
		if(msg.message == WM_QUIT) return FALSE;

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return TRUE;
}

static LRESULT CALLBACK mainwnd_wndproc(HWND p_wnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch(msg)
	{
		case WM_DESTROY:
			return mainwnd_event_wmdestroy(p_wnd, wparam, lparam);

		case WM_SIZE:
			return mainwnd_event_wmsize(p_wnd, wparam, lparam);

		case WM_PAINT:
			return mainwnd_event_wmpaint(p_wnd, wparam, lparam);

		case WM_CTLCOLORSTATIC:
			return window_event_wmctlcolorstatic(p_wnd, wparam, lparam);
	}

	return DefWindowProc(p_wnd, msg, wparam, lparam);
}

static LRESULT CALLBACK mainwnd_event_wmdestroy(HWND p_wnd, WPARAM wparam, LPARAM lparam)
{
	ULONG_PTR n_wnd;

	wglMakeCurrent(NULL, NULL);

	if(p_mygl != NULL)
	{
		if(p_mygl->p_wnd != NULL) DestroyWindow(p_mygl->p_wnd);
		delete p_mygl;
		p_mygl = NULL;
	}

	for(n_wnd = 0u; n_wnd < PP_CHILDWND_LENGTH; n_wnd++)
	{
		DestroyWindow(pp_childwnd[n_wnd]);
		pp_childwnd[n_wnd] = NULL;
	}

	p_mainwnd = NULL;

	PostQuitMessage(0);
	return 0;
}

static LRESULT CALLBACK mainwnd_event_wmsize(HWND p_wnd, WPARAM wparam, LPARAM lparam)
{
	if(p_wnd == NULL) return 0;

	childwnd_setup(TRUE);
	return 0;
}

static LRESULT CALLBACK mainwnd_event_wmpaint(HWND p_wnd, WPARAM wparam, LPARAM lparam)
{
	PAINTSTRUCT ps;

	if(p_wnd == NULL) return 0;

	if(BeginPaint(p_wnd, &ps) == NULL) return 0;

	FillRect(ps.hdc, &ps.rcPaint, pp_brush[MAINWND_BRUSHINDEX]);
	EndPaint(p_wnd, &ps);

	return 0;
}

static LRESULT CALLBACK glwnd_wndproc(HWND p_wnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	return DefWindowProc(p_wnd, msg, wparam, lparam);
}

static LRESULT CALLBACK window_event_wmctlcolorstatic(HWND p_wnd, WPARAM wparam, LPARAM lparam)
{
	if(p_wnd == NULL) return 0;
	if(!wparam) return 0;
	if(!lparam) return 0;

	SetTextColor((HDC) wparam, TEXTWND_TEXTCOLORREF);
	SetBkColor((HDC) wparam, TEXTWND_BKCOLORREF);

	return (LRESULT) pp_brush[TEXTWND_BRUSHINDEX];
}
